class shapeMetrics {
  float area, circularity, smoothness, xPos, yPos;
  
  shapeMetrics(ArrayList<PVector> shape) {
    calculateAll(shape);
  }
  
  void calculateAll(ArrayList<PVector> shape) {
    this.area = calculateArea(shape);
    this.circularity = calculateCircularity(shape);
    this.smoothness = calculateSmoothness(shape);
    
    PVector centroid = calculateCentroid(shape);
    this.xPos = centroid.x;
    this.yPos = centroid.y;
  }
}
