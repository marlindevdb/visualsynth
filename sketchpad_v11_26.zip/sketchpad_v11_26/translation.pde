//Translation from shapes to sound parameters
void translate() {
  int newShapeIndex = shapeMetrics.size() - 1;
  shapeMetrics metrics = shapeMetrics.get(newShapeIndex);
  ArrayList<PVector> currentShape = allShapes.get(allShapes.size() - 1);
  
  println("----------------");
  println("Instrument " + newShapeIndex + ":");
  println("Area: " + nf(metrics.area, 0, 1));
  println("Circularity: " + nf(metrics.circularity, 0, 2));
  println("Smoothness: " + nf(metrics.smoothness, 0, 2));
  println("YPos: " + nf(metrics.yPos, 0, 2));
  println("----------------");
  
  float maxArea = width * height * 0.15f; //Shapes bigger than max area will translate to volume 1
  float mappedArea = constrain(map(metrics.area, 2000, maxArea, -1, 1), -1, 1);
  float mappedCircularity = map(metrics.circularity, 0, 1, -1, 1);
  float mappedSmoothness = constrain(map(metrics.smoothness, 0.5, 1, -1, 1), -1, 1);
  float mappedYPos = map(metrics.yPos, 0, height, -1, 1);
  float mappedXPos = map(metrics.xPos, width, 0, -1, 1);
  
  
  //In what way the shape properties are mapped to sound properties
  float loudnessCalc = mappedArea;
  float leftVolumeCalc = mappedXPos;
  float rightVolumeCalc = mappedXPos*-1;
  float pitchCalc = constrain((mappedArea * -0.4) + (mappedSmoothness * -0.1) + (mappedYPos * -0.6), -1, 1);
  float timbreCalc = constrain((mappedCircularity * 0.2) + (mappedSmoothness * 0.8), -1, 1);
  float tempoCalc = constrain((mappedCircularity*0.3) + (mappedArea*0.7), -1, 1);
  
  
  float tempo = 0;
  if (tempoCalc < -0.6) {
    tempo = 0.25;
  } else if (tempoCalc < -0.2) {
    tempo = 0.5;
  } else if (tempoCalc < 0.2) {
    tempo = 1;
  } else if (tempoCalc < 0.6) {
    tempo = 2;
  } else {
    tempo = 4;
  } 
  
  //Make the values in between 0 & 1
  float loudness = ((loudnessCalc + 1) / 2.0)*100;
  float leftVolumePre = ((leftVolumeCalc + 1) / 2.0)*100;
  float rightVolumePre = ((rightVolumeCalc + 1) / 2.0)*100;
  int leftVolume = int(loudness*(leftVolumePre/100));
  int rightVolume = int(loudness*(rightVolumePre/100));
  
  if (leftVolume == 0 && rightVolume == 0) {
    if (leftVolumeCalc >= rightVolumeCalc) {
      leftVolume = 1;
    } else {
      rightVolume = 1;
    }      
  }
  
  if (leftVolume > 35) {
    leftVolume = 35;
  } else if (rightVolume > 35) {
    rightVolume = 35;
  }
 
 
  //float pitch = (pitchCalc + 1) / 2.0;
  //float timbre = (timbreCalc + 1) / 2.0;
  
  int pitch = 0;
  if (pitchCalc < -0.6) {
    pitch = 4;
  } else if (pitchCalc < -0.2) {
    pitch = 3;
  } else if (pitchCalc < 0.2) {
    pitch = 2;
  } else if (pitchCalc < 0.6) {
    pitch = 1;
  } else {
    pitch = 0;
  } 
  
  int timbre = 0;
  if (timbreCalc < -0.6) {
    timbre = 0;
  } else if (timbreCalc < -0.2) {
    timbre = 1;
  } else if (timbreCalc < 0.2) {
    timbre = 2;
  } else if (timbreCalc < 0.6) {
    timbre = 3;
  } else {
    timbre = 4;
  } 
  
  //Create and send instrument
  Instrument inst = new Instrument(pitch, timbre, tempo, leftVolume, rightVolume, newShapeIndex, currentShape);
  instruments.add(inst);
  
  // Log the shape addition
  if (loggingEnabled && dataLogger != null) {
    activeShapeIds = getActiveShapeIds();
    dataLogger.logShapeWithPoints("ADD", newShapeIndex, metrics, inst, currentShape, activeShapeIds);
  }
  
  sendInstrument(inst);
  
  println("Created and sent instrument #" + newShapeIndex);
  inst.display();
}

void sendInstrument(Instrument inst) {
  OscMessage message = new OscMessage("/instrument");
  
  message.add(inst.id);
  message.add(inst.pitch);
  message.add(inst.timbre);
  message.add(inst.tempo);
  message.add(inst.leftVolume);
  message.add(inst.rightVolume);

  oscP5.send(message, sonicPi);
  println("Sent instrument " + inst.id + " to Sonic Pi");
}

void sendClearMessage() {
  OscMessage message = new OscMessage("/clear");
  oscP5.send(message, sonicPi);
  println("Sent clear message to Sonic Pi");
}

void sendInstrumentStop(int instrumentId) {
  OscMessage message = new OscMessage("/stop_instrument");
  message.add(instrumentId);
  oscP5.send(message, sonicPi);
  println("Sent stop message for instrument " + instrumentId + " to Sonic Pi");
}
