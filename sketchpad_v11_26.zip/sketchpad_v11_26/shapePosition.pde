PVector calculateCentroid(ArrayList<PVector> shape) {
  float cx = 0, cy = 0;
  for (PVector p : shape) {
    cx += p.x;
    cy += p.y;
  }
  cx /= shape.size();
  cy /= shape.size();
  return new PVector(cx, cy);
}
