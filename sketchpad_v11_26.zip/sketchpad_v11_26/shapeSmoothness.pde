ArrayList<Float> angles = new ArrayList<Float>();

float calculateSmoothness(ArrayList<PVector> shape) {
  if (shape.size() < 5) return 1.0; //Otherwise too few points to measure
  
  ArrayList<Float> angleDeltas = new ArrayList<Float>();
  int n = shape.size();
  
  for (int i = 0; i < n; i++) { //Calculation of angles
    PVector prev = shape.get((i-1+n) % n);
    PVector curr = shape.get(i);
    PVector next = shape.get((i+1) % n);
    
    PVector inVec = PVector.sub(prev, curr);
    PVector outVec = PVector.sub(next, curr);
    float angle = atan2(outVec.y, outVec.x) - atan2(inVec.y, inVec.x);
    angle = (angle + TWO_PI) % TWO_PI;
    
    angleDeltas.add(angle);
  }
  
  float totalAccel = 0; //Angular acceleration
  for (int i = 0; i < n; i++) {
    float prevAngle = angleDeltas.get((i-1+n) % n);
    float currAngle = angleDeltas.get(i);
    float nextAngle = angleDeltas.get((i+1) % n);
    
    float accel = abs((nextAngle - currAngle) - (currAngle - prevAngle)); //How much angle changes
    totalAccel += accel;
  }
  
  float smoothness = 1 - (totalAccel / (n*PI)); //Normalizing against most extreme shape (=alternating sharp angles)
  
  return constrain(smoothness, 0, 1);
}

/*

Old method (variance of angles as smoothness)

float calculateMeanAngle(ArrayList<Float> angles) {
  if (angles.isEmpty()) return 0;
  float sum = 0;
  for (float a : angles) {
    sum += a;
  }
  
  float meanAngles = sum / angles.size();
  println(angles);
  
  return meanAngles;
  
  //float perimeter = calculatePerimeter(shape);
  //return min(avgCurvature/perimeter, 1.0);
}

float calculateAngleVariance(ArrayList<Float> angles) {
  
  if (angles.size() < 2) return 0;
  float mean = calculateMeanAngle(angles);
  float sumSq = 0;
  
  for (float a : angles) {
    sumSq += sq(a - mean);
  }
  
  return sumSq / (angles.size() - 1); //Sample variance
}
*/
