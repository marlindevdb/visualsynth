float calculateCircularity(ArrayList<PVector> shape) {
  float area = calculateArea(shape);
  float perimeter = calculatePerimeter(shape);
  
  if (perimeter == 0) return 0;
  if (area <= 0) return 0;
  
  float circularity = (4 * PI * area) / (perimeter * perimeter);
  return constrain(circularity, 0, 1);
}

float calculatePerimeter(ArrayList<PVector> shape) {
  if (shape.size() < 2) return 0;
  
  float perimeter = 0;
  int n = shape.size();
  
  for (int i = 0; i < n; i++) {
    PVector curr = shape.get(i);
    PVector next = shape.get((i+1) % n);
    perimeter += PVector.dist(curr, next);
  }
  
  return perimeter;
}
