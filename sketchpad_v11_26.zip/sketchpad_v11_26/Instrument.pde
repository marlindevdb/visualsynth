class Instrument {
  float pitch, timbre, tempo, leftVolume, rightVolume;
  int id;
  ArrayList<PVector> shapeReference;

  
  Instrument(float p, float t, float tmp, float lV, float rV, int shapeId, ArrayList<PVector> shape) {
    pitch = p;
    timbre = t;
    id = shapeId;
    tempo = tmp;
    leftVolume = lV;
    rightVolume = rV;
    shapeReference = new ArrayList<PVector>(shape);
  }
  
  void display() {
    println("----------------");
    println("Instrument " + id + ":");
    println(" Pitch: " + nf(pitch, 0, 2));
    println(" Timbre: " + nf(timbre, 0, 2));
    println(" Tempo: " + nf(tempo, 0, 3));
    println(" Left Volume: " + nf(leftVolume, 0, 2));
    println(" Right Volume: " + nf(rightVolume, 0, 2));
    println("----------------");

  }
}
