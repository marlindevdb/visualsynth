float calculateArea(ArrayList<PVector> shape) {
  float area = 0;
  int n = shape.size();
  
  for (int i = 0; i < n; i++) {
    PVector current = shape.get(i);
    PVector next = shape.get((i + 1) % n);
    area += (current.x * next.y) - (current.y * next.x);
  }
  
  return abs(area) * 0.5;
}
