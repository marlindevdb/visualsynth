class DataLogger {
  String participantID;
  String sessionID;
  long sessionStartTime;
  String logFilePath;
  String eventLogFilePath;
  int currentTask;
  
  DataLogger(String pid) {
    participantID = pid;
    sessionID = participantID + "_" + year() + "-" + month() + "-" + day() + "_" + hour() + "-" + minute() + "-" + second();
    sessionStartTime = millis();
    currentTask = -1;
    
    File dataDir = new File(sketchPath("data"));
    if (!dataDir.exists()) {
      dataDir.mkdir();
    }
    
    logFilePath = "data/shape_data_" + sessionID + ".csv";
    eventLogFilePath = "data/events_" + sessionID + ".csv";
    
    setupLogFiles();
  }
  
  void setCurrentTask(int task) {
    this.currentTask = task;
  }
  
  int getCurrentTask() {
    return currentTask;
  }
  
  void setupLogFiles() {
    String[] shapeHeaders = {
      "timestamp", "event_type", "shape_id", "participant_id", "session_id", "task_id",
      "active_shape_ids", "total_shapes",
      "area", "circularity", "smoothness", "centroid_x", "centroid_y",
      "pitch", "timbre", "tempo", "left_volume", "right_volume", "shape_points"
    };
    saveStrings(logFilePath, new String[]{join(shapeHeaders, ";")});
    
    String[] eventHeaders = {
      "timestamp", "event_type", "shape_id", "participant_id", "session_id", "task_id", 
      "active_shape_ids", "total_shapes", "details"
    };
    saveStrings(eventLogFilePath, new String[]{join(eventHeaders, ";")});
  }
  
  void logShapeEvent(String eventType, int shapeId, Instrument instrument, ArrayList<Integer> activeShapeIds, shapeMetrics metrics) {
    String timestamp = str(millis() - sessionStartTime);
    String activeIdsStr = getActiveIdsString(activeShapeIds);
    
    String pointsStr = "";
    if (eventType.equals("ADD") && metrics != null) {
      pointsStr = "points_available";
    }
    
    String[] data = {
      timestamp,
      eventType,
      str(shapeId),
      participantID,
      sessionID,
      str(currentTask),
      activeIdsStr,
      str(activeShapeIds.size()),
      metrics != null ? nf(metrics.area, 0, 2) : "",
      metrics != null ? nf(metrics.circularity, 0, 3) : "",
      metrics != null ? nf(metrics.smoothness, 0, 3) : "",
      metrics != null ? nf(metrics.xPos, 0, 2) : "",
      metrics != null ? nf(metrics.yPos, 0, 2) : "",
      instrument != null ? nf(instrument.pitch, 0, 2) : "",
      instrument != null ? nf(instrument.timbre, 0, 2) : "",
      instrument != null ? nf(instrument.tempo, 0, 3) : "",
      instrument != null ? nf(instrument.leftVolume, 0, 2) : "",
      instrument != null ? nf(instrument.rightVolume, 0, 2) : "",
      pointsStr
    };
    
    appendToCSV(logFilePath, data);
    
    println("Logged " + eventType + " event for shape " + shapeId + " in task " + currentTask);
  }
  
  void logGeneralEvent(String eventType, String details, ArrayList<Integer> activeShapeIds) {
    String timestamp = str(millis() - sessionStartTime);
    String activeIdsStr = getActiveIdsString(activeShapeIds);
    
    String[] data = {
      timestamp,
      eventType,
      "",
      participantID,
      sessionID,
      str(currentTask),
      activeIdsStr,
      str(activeShapeIds.size()),
      details
    };
    
    appendToCSV(eventLogFilePath, data);
    
    println("Logged event: " + eventType + " - " + details + " in task " + currentTask);
  }
  
  void logShapeWithPoints(String eventType, int shapeId, shapeMetrics metrics, Instrument instrument, 
                         ArrayList<PVector> shapePoints, ArrayList<Integer> activeShapeIds) {
    String timestamp = str(millis() - sessionStartTime);
    String activeIdsStr = getActiveIdsString(activeShapeIds);
    
    String pointsStr = "";
    for (PVector p : shapePoints) {
      pointsStr += nf(p.x, 0, 1) + ":" + nf(p.y, 0, 1) + ";";
    }
    if (pointsStr.length() > 0) {
      pointsStr = pointsStr.substring(0, pointsStr.length() - 1);
    }
    
    String[] data = {
      timestamp,
      eventType,
      str(shapeId),
      participantID,
      sessionID,
      str(currentTask),
      activeIdsStr,
      str(activeShapeIds.size()),
      nf(metrics.area, 0, 2),
      nf(metrics.circularity, 0, 3),
      nf(metrics.smoothness, 0, 3),
      nf(metrics.xPos, 0, 2),
      nf(metrics.yPos, 0, 2),
      nf(instrument.pitch, 0, 2),
      nf(instrument.timbre, 0, 2),
      nf(instrument.tempo, 0, 3),
      nf(instrument.leftVolume, 0, 2),
      nf(instrument.rightVolume, 0, 2),
      pointsStr
    };
    
    appendToCSV(logFilePath, data);
    
    println("Logged " + eventType + " event for shape " + shapeId + " with points in task " + currentTask);
  }
  
  String getActiveIdsString(ArrayList<Integer> activeShapeIds) {
    String result = "";
    for (int id : activeShapeIds) {
      result += id + ",";
    }
    if (result.length() > 0) {
      result = result.substring(0, result.length() - 1);
    }
    return result;
  }
  
  void appendToCSV(String filePath, String[] data) {
    String[] existing = {};
    try {
      existing = loadStrings(filePath);
    } catch (Exception e) {
    }
    
    String[] newData = new String[existing.length + 1];
    arrayCopy(existing, newData);
    newData[existing.length] = join(data, ";");
    
    try {
      saveStrings(filePath, newData);
    } catch (Exception e) {
      println("Error saving to " + filePath + ": " + e.getMessage());
    }
  }
}
