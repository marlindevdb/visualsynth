import oscP5.*;
import netP5.*;

OscP5 oscP5;
NetAddress sonicPi;

ArrayList<PVector> currentShape;
ArrayList<ArrayList<PVector>> allShapes = new ArrayList<ArrayList<PVector>>();

ArrayList<shapeMetrics> shapeMetrics = new ArrayList<shapeMetrics>();
ArrayList<Instrument> instruments = new ArrayList<Instrument>();

color fillColor = color(0, 50);
float minDistance = 10;
int instrumentLimit = 10;

boolean drawMode = true;
color eraseColor = color(255, 0, 0, 50);

DataLogger dataLogger;
String currentParticipantID = "default";
ArrayList<Integer> activeShapeIds = new ArrayList<Integer>();
boolean loggingEnabled = true;

int currentTask = -1; // -1 means no task active, 0 = free exploration, 1-8 = tasks
boolean taskActive = false;

String currentTaskInstruction = "";
String[] taskInstructions = {
  "Free Exploration: Draw any shapes you like",
  "Draw a shape that sounds LOUD",
  "Draw a shape that sounds SOFT", 
  "Draw a shape with HIGH PITCH",
  "Draw a shape with LOW PITCH",
  "Draw a shape that sounds SHRILL",
  "Draw a shape that sounds WARM",
  "Draw a shape with FAST tempo",
  "Draw a shape with SLOW tempo"
};

ArrayList<Integer> getActiveShapeIds() {
  ArrayList<Integer> ids = new ArrayList<Integer>();
  for (int i = 0; i < allShapes.size(); i++) {
    ids.add(i);
  }
  return ids;
}


void setup() {
  fullScreen();
  background(255);
  strokeWeight(4);
  stroke(0, 50);
  noFill();
  textSize(16);
  
  oscP5 = new OscP5(this, 8000);
  sonicPi = new NetAddress("127.0.0.1", 4560); 
  
  currentParticipantID = "default_participant";
  dataLogger = new DataLogger(currentParticipantID);
  loggingEnabled = true;
  println("Logger auto-initialized for: " + currentParticipantID);
}

void draw() {
  background(255);
  
  drawModeButtons();   

  //Draw all completed shapes
  for (int i = 0; i < allShapes.size(); i++) {
    ArrayList<PVector> shape = allShapes.get(i);
    if (drawMode == true) {
      fill(fillColor);
    } else {
      fill(eraseColor);
    }
    drawClosedShape(shape);
    
    //Display shape metrics, only turned on to check values on canvas
    /*
    shapeMetrics metrics = shapeMetrics.get(i);
    PVector firstPoint = shape.get(0);
    fill(0);
    text("Area: " + nf(metrics.area, 0, 1) + " px²", firstPoint.x + 20, firstPoint.y);
  
    text(
      "C: " + nf(metrics.circularity, 0, 2) + 
      " Sm: " + nf(metrics.smoothness, 0, 2) +
      " yPos: " + nf(metrics.yPos, 0, 2),
      metrics.xPos,
      metrics.yPos
    );
    */
  }
  
  //Draw current shape being drawn
  if (currentShape != null && currentShape.size() > 1) {
    noFill();
    beginShape();
    for (PVector point : currentShape) {
      vertex(point.x, point.y);
    }
    endShape();
  }
  
  if (instruments.size() >= instrumentLimit) {
    push();
      noStroke();
      fill(255, 0, 0, 150);
      rect(0, 0, width, 30);
      fill(255);
      text("Instrument limit reached! Remove some shapes to draw more.", 10, 20);
    pop();
    drawMode = false;
  }
  
  push();
    fill(0);
    textAlign(LEFT);
    textSize(16);
    String taskInfo = "Current: " + 
      (currentTask == -1 ? "-" : 
       (currentTask == 0 ? "Free Exploration" : currentTask + " - " + currentTaskInstruction));
    text(taskInfo, 20, 50);
  pop();

}

void drawClosedShape(ArrayList<PVector> shape) {
  beginShape();
  for (PVector point : shape) {
    vertex(point.x, point.y);
  }
  endShape(CLOSE);
}

void mousePressed() {
  if (((mouseX > width-240 && mouseX < width-240+45) || (mouseX > width-150 && mouseX < width-150+80)) && (mouseY < 45+30 && mouseY > 45)) {
    //changing mode
    if (mouseX > width-240 && mouseX < width-240+45) {
      if (drawMode == false) {
        clearAll();
        drawMode = true;
      }
    } else if (mouseX > width-150 && mouseX < width-150+80) {
      drawMode = !drawMode;
    }
  } else if (drawMode == false) {
    for (int i = allShapes.size() - 1; i >= 0; i--) {
      if (isPointInShape(mouseX, mouseY, allShapes.get(i))) {
        removeShape(i);
        return;
      }
    }
  } else if (drawMode == true) {
    currentShape = new ArrayList<PVector>();
    currentShape.ensureCapacity(100);
    currentShape.add(new PVector(mouseX, mouseY));
  }
}

void mouseDragged() {
  if (currentShape != null) {
    PVector last = currentShape.get(currentShape.size()-1);
    if (dist(mouseX, mouseY, last.x, last.y) > minDistance) {
      currentShape.add(new PVector(mouseX, mouseY));
    }
  }
}

void mouseReleased() {
  if (currentShape != null && currentShape.size() > 2) {
    allShapes.add(new ArrayList<PVector>(currentShape));
    
    shapeMetrics.add(new shapeMetrics(currentShape));

    translate();
  }
  currentShape = null;
  

}

void keyPressed() {
  println("Key pressed: " + key + " (keyCode: " + keyCode + ")");
  println("Current task: " + currentTask + ", Task active: " + taskActive);
  println("DataLogger exists: " + (dataLogger != null));
  

  if (key >= '0' && key <= '8') {
    int taskNumber = key - '0'; 
    println("Processing task number: " + taskNumber);
    
    if (taskNumber == currentTask) {
      println("Ending current task");
      endCurrentTask();
    } else {
      println("Switching to new task");
      switchToTask(taskNumber);
    }
  } else if (key == 'c' || key == 'C') {
    println("Clearing all shapes");
    clearAll(); 
  } else if (key == 'l' || key == 'L') {
    println("Initializing logger");
    if (dataLogger == null) {
      dataLogger = new DataLogger(currentParticipantID);
      println("Data logging started for participant: " + currentParticipantID);
    } else {
      println("Logger already exists");
    }
  }
}

void switchToTask(int taskNumber) {
  if (taskActive && dataLogger != null) {
    dataLogger.logGeneralEvent("TASK_END", "Switching to new task", getActiveShapeIds());
  }
  
  currentTask = taskNumber;
  taskActive = true;
  
  if (taskNumber >= 0 && taskNumber < taskInstructions.length) {
    currentTaskInstruction = taskInstructions[taskNumber];
  } else {
    currentTaskInstruction = "Unknown Task";
  }
  
  if (dataLogger != null) {
    dataLogger.setCurrentTask(taskNumber);
    
    String taskDescription = (taskNumber == 0) ? "Free Exploration" : ("Task " + taskNumber);
    dataLogger.logGeneralEvent("TASK_START", taskDescription, getActiveShapeIds());
  }
  
  println("Switched to " + ((taskNumber == 0) ? "Free Exploration" : "Task " + taskNumber));
  
  clearAll();
}

void endCurrentTask() {
  if (taskActive && dataLogger != null) {
    dataLogger.logGeneralEvent("TASK_END", "Task completed", getActiveShapeIds());
    
    String taskDescription = (currentTask == 0) ? "Free Exploration" : ("Task " + currentTask);
    println("Ended " + taskDescription);
  }
  
  currentTask = -1;
  taskActive = false;
  
  if (dataLogger != null) {
    dataLogger.setCurrentTask(-1);
  }

  clearAll();
}

void initializeSession(String participantId) {
  currentParticipantID = participantId;
  dataLogger = new DataLogger(participantId);
  loggingEnabled = true;
  
  currentTask = -1;
  taskActive = false;
  
  println("Session initialized for: " + participantId);
  
  dataLogger.logGeneralEvent("SESSION_START", "Experiment session started", new ArrayList<Integer>());
}

boolean isPointInShape(float x, float y, ArrayList<PVector> shape) {
  if (shape.size() < 3) return false; // Need at least 3 points for a polygon
  
  boolean inside = false;
  int j = shape.size() - 1;
  
  for (int i = 0; i < shape.size(); i++) {
    PVector vi = shape.get(i);
    PVector vj = shape.get(j);     
    if (((vi.y > y) != (vj.y > y)) && (x < (vj.x - vi.x) * (y - vi.y) / (vj.y - vi.y) + vi.x)) {  //Ray casting algorithm
      inside = !inside;
    }
    j = i;
  }
  return inside;
}

void removeShape(int index) {
  if (index < 0 || index >= allShapes.size()) return;
  
  int instrumentIdToStop = -1;
  shapeMetrics metricsToLog = null;
  Instrument instrumentToLog = null;
  ArrayList<PVector> shapeToLog = null;
  
  if (index < instruments.size()) {
    instrumentToLog = instruments.get(index);
    instrumentIdToStop = instrumentToLog.id;
    shapeToLog = instrumentToLog.shapeReference;
  }
  if (index < shapeMetrics.size()) {
    metricsToLog = shapeMetrics.get(index);
  }
  
  if (loggingEnabled && dataLogger != null && metricsToLog != null && instrumentToLog != null) {
    ArrayList<Integer> activeBeforeRemoval = getActiveShapeIds();
    dataLogger.logShapeEvent("REMOVE", index, instrumentToLog, activeBeforeRemoval, metricsToLog);
  }
  
  allShapes.remove(index);
  if (index < shapeMetrics.size()) {
    shapeMetrics.remove(index);
  }
  if (index < instruments.size()) {
    instruments.remove(index);
  }
  
  activeShapeIds = getActiveShapeIds();
  
  sendInstrumentStop(instrumentIdToStop);
  println("Removed shape and instrument #" + instrumentIdToStop);
}

void clearAll() {
  if (loggingEnabled && dataLogger != null) {
    ArrayList<Integer> activeBeforeClear = getActiveShapeIds();
    dataLogger.logGeneralEvent("CLEAR_ALL", "User initiated clear", activeBeforeClear);
  }
  
  allShapes.clear();
  shapeMetrics.clear();
  instruments.clear();
  activeShapeIds.clear();
  
  sendClearMessage();
  println("Cleared all shapes and instruments");
}

void drawModeButtons() {
  push();
    noFill();
    stroke(100);
    strokeWeight(5);
    rect(width-150, 30, 80, 45, 100);
    if (drawMode == false) {
      rect(width-240, 30, 45, 45, 8);
      float rectX = width-240;
      float rectY = 30;
      float rectSize = 45;
      float centerX = rectX + rectSize/2;
      float centerY = rectY + rectSize/2;
      float crossSize = 12;
      line(centerX - crossSize, centerY - crossSize, centerX + crossSize, centerY + crossSize);
      line(centerX + crossSize, centerY - crossSize, centerX - crossSize, centerY + crossSize);
      
      fill(100);
      circle(width-125, 52.5, 30);
      
      fill(100);
      textAlign(CENTER);
      text("erasing mode", width-110, 100);
    } else {
      fill(100);
      circle(width-125+30, 52.5, 30);
      textAlign(CENTER);
      text("drawing mode", width-110, 100);
    }
  pop();
}
